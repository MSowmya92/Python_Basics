A python project to check plagiarism on text files[.txt].
Environment:
Windows 7 64 bit
Python 3.6

Approach: using Longest Substring in the two documents

Author:
Gurunath Reddy Kambala
20176012