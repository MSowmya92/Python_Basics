__all__=["getFileContents"]
